# pylint: skip-file
from opendbc.can.packer_pyx import CANPacker
assert CANPacker
